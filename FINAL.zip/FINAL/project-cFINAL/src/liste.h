#ifndef LISTE_H_INCLUDED
#define LISTE_H_INCLUDED
#include <stdio.h>
#include <gtk/gtk.h>
typedef struct
{
    int jour;
    int mois;
    int annee;
}date;

typedef struct
{
    int idListe;
    int idtete;
    char orientation[20];
    date date_depot;
    int id1,id2,id3;
    int nbvotes;
} liste;
//le type de  retour int c'est pour indiquer si la tache a été réalisée avec succés ou non
//pour afficher des lsg plus tard exemple erreur d'ouverture de fichier, element introuvable
int ajouter(char * filename, liste l );
int modifier( char * filename, int id, liste nouv );
int supprimer(char * filename, int id);
liste chercher(char id[]);
void afficher(GtkWidget *pListView);
void supprimer_liste(liste l);
//void Chercher_entrymariem(GtkWidget *LISTE,char ch[20]);
void afficher_cher_mariem(GtkWidget *pListView);
#endif // LISTE_H_INCLUDED
