#include <gtk/gtk.h>


void
on_buttonajoutliste_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifliste_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsuppliste_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffliste_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvote_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_M_chercher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_M_Modifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconfirmerajout_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewaffichage_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvotevote_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
