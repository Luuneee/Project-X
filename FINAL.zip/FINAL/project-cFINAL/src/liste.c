#include "liste.h"
#include <string.h>
#include <gtk/gtk.h>
enum{   IDLISTE,
	IDTETE,
	ORIENTATION,
	JOUR,
	MOIS,
	ANNEE,
	ID1,
	ID2,
	ID3,
	NBVOTES,
     N_COLUMNS,};
/*enum{
	IDLISTE,
	IDTETE,
	JOUR,
	MOIS,
	ANNEE,
	ORIENTA,
	ID1,
	ID2,
	ID3,
	COLUMNS
};*/
int ajouter(char * filename, liste l )
{
    FILE * f=fopen(filename, "a");
    if(f!=NULL)
    {
        fprintf(f,"%d %d %s %d %d %d %d %d %d \n",l.idListe,l.idtete,l.orientation,l.date_depot.jour,l.date_depot.mois,l.date_depot.annee,l.id1,l.id2,l.id3);
        fclose(f);
        return 1;
    }
    else return 0;
}
int modifier( char * filename, int id, liste nouv )
{
    int tr=0;
    liste l;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)
        {
            if(l.idListe== id)
            {
                fprintf(f2,"%d %d %s %d %d %d %d %d %d \n",nouv.idListe,nouv.idtete,nouv.orientation,nouv.date_depot.jour,nouv.date_depot.mois,nouv.date_depot.annee,nouv.id1,nouv.id2,nouv.id3);
                tr=1;
            }
            else
                fprintf(f2,"%d %d %s %d %d %d %d %d %d \n",l.idListe,l.idtete,l.orientation,l.date_depot.jour,l.date_depot.mois,l.date_depot.annee,l.id1,l.id2,l.id3);

        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;

}
int supprimer(char * filename, int id)
{
    int tr=0;
    liste l;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)
        {
            if(l.idListe== id)
                tr=1;
            else
                fprintf(f2,"%d %d %s %d %d %d %d %d %d \n",l.idListe,l.idtete,l.orientation,l.date_depot.jour,l.date_depot.mois,l.date_depot.annee,l.id1,l.id2,l.id3);
        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
}
liste chercher(char id[])
{   int idl = atoi (id);
    liste l;
    int tr=0;
    FILE * f=fopen("liste.txt", "r");
    if(f!=NULL)
    {
        while((tr==0)&& (fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF))
        {
            if(l.idListe== idl)
                tr=1;
        }
    }
       fclose(f);
    if(tr==0)
        l.idListe=-1;
    return l;

}

void afficher(GtkWidget *pListView) 
{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;

	liste l;
char var1[20],var2[20],var3[20],var4[20],var5[20],var6[20],var7[20],var8[20];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id_liste",pCellRenderer,"text", IDLISTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id_tete",pCellRenderer,"text",IDTETE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);
pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("orientation",pCellRenderer,"text",ORIENTATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("jour_depot",pCellRenderer,"text", JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("mois_depot",pCellRenderer,"text", MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);
pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("annee_depot",pCellRenderer,"text", ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);
pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("idc1",pCellRenderer,"text", ID1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("idc2",pCellRenderer,"text", ID2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("idc3",pCellRenderer,"text", ID3,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);


pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nombres_votes",pCellRenderer,"text", NBVOTES,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);





pListStore = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);

f=fopen("liste.txt","r");
if (f==NULL){return;}

else{
f=fopen("liste.txt","a+");

while(fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)
{

sprintf(var1,"%d",l.idListe);
sprintf(var2,"%d",l.idtete);
sprintf(var3,"%d",l.date_depot.jour);
sprintf(var4,"%d",l.date_depot.mois);
sprintf(var5,"%d",l.date_depot.annee);
sprintf(var6,"%d",l.id1);
sprintf(var7,"%d",l.id2);
sprintf(var8,"%d",l.id3);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,IDLISTE,var1,IDTETE,var2,ORIENTATION,l.orientation,JOUR,var3,MOIS,var4,ANNEE,var5,ID1,var6,ID2,var7,ID3,var8,-1);

}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}

}

/*
void afficher(GtkWidget *pListView)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	store=NULL;
	FILE *f;
	liste l;
	store=gtk_tree_view_get_model(pListView);

	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("id_liste", renderer, "text", IDLISTE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("id_tete", renderer, "text",IDTETE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text",JOUR, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Mois", renderer, "text",MOIS, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Annee", renderer, "text",ANNEE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("orientation", renderer, "text",ORIENTATION, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("candidat_1", renderer, "text",ID1, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);
	
	
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("candidat_2", renderer, "text",ID2, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);
	

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("candidat_3", renderer, "text",ID3, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), column);
	
	}
	 store=gtk_list_store_new (N_COLUMNS,
	 				 G_TYPE_UINT,
					 G_TYPE_UINT,
					 G_TYPE_STRING,
					 G_TYPE_UINT,
					 G_TYPE_UINT,
					 G_TYPE_UINT,
					 G_TYPE_UINT,
					G_TYPE_UINT,
					G_TYPE_UINT);

	f=fopen("liste.txt", "r");
	if(f==NULL)
	{
		return;
	}
	else{
	
	while(fscanf(f,"%d %d %s %d %d %d %d %d %d",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)
	{
	gtk_list_store_append (store, &iter); 
	gtk_list_store_set (store,&iter,IDLISTE,l.idListe,IDTETE,l.idtete,JOUR,l.date_depot.jour,MOIS,l.date_depot.mois,ANNEE,l.date_depot.annee,ORIENTATION,l.orientation,ID1,l.id1,ID2,l.id2,ID3,l.id3);
	}
	fclose(f);

	gtk_tree_view_set_model (GTK_TREE_VIEW (pListView), GTK_TREE_MODEL (store)); 
	g_object_unref (store);
	}
}
*/
void supprimer_liste(liste l)
    {   liste l1;
	FILE *f, *g;
	f=fopen("liste.txt","r");
	g=fopen("liste1.txt","w");
	if(f==NULL || g==NULL)
	  { return;
	  }
	else
	{while(fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)
{
if( strcmp(l.idListe,l1.idListe)!=0) 

fprintf(f,"%d %d %s %d %d %d %d %d %d \n",l.idListe,l.idtete,l.orientation,l.date_depot.jour,l.date_depot.mois,l.date_depot.annee,l.id1,l.id2,l.id3);
}
fclose(f);
fclose(g);
remove("liste.txt");
rename("liste1.txt","liste.txt");
	}
    }
/*
void Chercher_entrymariem(GtkWidget *LISTE,char ch[20])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char var1[20],var2[20],var3[20],var4[20],var5[20],var6[20],var7[20],var8[20];
store=NULL;
FILE *f=NULL;
store=gtk_tree_view_get_model(LISTE);
if(store==NULL)
{
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("id_liste", renderer, "text", IDLISTE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("id_tete", renderer, "text",IDTETE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text",JOUR, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Mois", renderer, "text",MOIS, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Annee", renderer, "text",ANNEE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("orientation", renderer, "text",ORIENTATION, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);

	
	
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("candidat_1", renderer, "text",ID1, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);
	

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("candidat_2", renderer, "text",ID2, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);
	

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("candidat_3", renderer, "text",ID3, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (LISTE), column);
}
store=gtk_list_store_new (N_COLUMNS, G_TYPE_UINT,
					 G_TYPE_UINT,
					 G_TYPE_STRING,
					 G_TYPE_UINT,
					 G_TYPE_UINT,
					 G_TYPE_UINT,
					 G_TYPE_UINT,
					G_TYPE_UINT,
					G_TYPE_UINT);
f=fopen("liste.txt","r");
liste l;
{f=fopen("liste.txt","a+");
	while(fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)
{	 if (strcmp(ch,l.orientation)==0){
	gtk_list_store_append (store, &iter); 
	gtk_list_store_set(store,&iter,
IDLISTE,var1,IDTETE,var2,ORIENTATION,l.orientation,JOUR,var3,MOIS,var4,ANNEE,var5,ID1,var6,ID2,var7,ID3,var8,-1);
}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (LISTE), GTK_TREE_MODEL(store)); 
	g_object_unref (store);
}
}
}*/
//CHERCHERRRRRRRR
void afficher_cher_mariem(GtkWidget *pListView) 
{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
int idListe;
    	int idtete;
    	int jour;
    	char mois;
    	int annee;
    	int id1,id2,id3;
char orientation[20];
	liste l;
char var1[20],var2[20],var3[20],var4[20],var5[20],var6[20],var7[20],var8[20];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("id_liste", pCellRenderer, "text", IDLISTE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("id_tete", pCellRenderer, "text",IDTETE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("Jour", pCellRenderer, "text",JOUR, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("Mois", pCellRenderer, "text",MOIS, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("Annee", pCellRenderer, "text",ANNEE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("orientation", pCellRenderer, "text",ORIENTATION, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);

	
	
	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("candidat_1", pCellRenderer, "text",ID1, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);
	

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("candidat_2", pCellRenderer, "text",ID2, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);
	

	pCellRenderer = gtk_cell_renderer_text_new (); 
	pColumn = gtk_tree_view_column_new_with_attributes("candidat_3", pCellRenderer, "text",ID3, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (pListView), pColumn);


pListStore = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("liste.txt","r");
if (f==NULL){return;}

else{
f=fopen("liste1.txt","a+");

while((f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF)

{
sprintf(var1,"%d",l.idListe);
sprintf(var2,"%d",l.idtete);
sprintf(var3,"%d",l.date_depot.jour);
sprintf(var4,"%d",l.date_depot.mois);
sprintf(var5,"%d",l.date_depot.annee);
sprintf(var6,"%d",l.id1);
sprintf(var7,"%d",l.id2);
sprintf(var8,"%d",l.id3);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore,&pIter,
IDLISTE,var1,IDTETE,var2,ORIENTATION,l.orientation,JOUR,var3,MOIS,var4,ANNEE,var5,ID1,var6,ID2,var7,ID3,var8);
}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}
}

