#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "liste.h"
#include <string.h>

void
on_buttonajoutliste_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowgestionliste;//f1
  GtkWidget *windowajoutliste;//f2
  windowgestionliste = lookup_widget(button,"windowgestionliste");

  windowajoutliste = create_windowajoutliste();
  gtk_widget_show (windowajoutliste);
}


void
on_buttonmodifliste_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowgestionliste;//f1
  GtkWidget *windowmodifliste;//f2
  windowgestionliste = lookup_widget(button,"windowgestionliste");

  windowmodifliste = create_windowmodifliste ();
  gtk_widget_show (windowmodifliste);
}


void
on_buttonsuppliste_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowgestionliste;//f1
  GtkWidget *windowrechsupp;//f2
  windowgestionliste = lookup_widget(button,"windowgestionliste");
  
  windowrechsupp = create_windowrechsupp ();
  gtk_widget_show (windowrechsupp);
}


void
on_buttonaffliste_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowgestionliste;//f1
  GtkWidget *windowaffichageliste;//f2
  windowgestionliste = lookup_widget(button,"windowgestionliste");
  
  windowaffichageliste = create_windowaffichageliste ();
  gtk_widget_show (windowaffichageliste);
}


void
on_buttonvote_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowgestionliste;//f1
  GtkWidget *windowvote;//f2
  windowgestionliste = lookup_widget(button,"windowgestionliste");

  windowvote = create_windowvote ();
  gtk_widget_show (windowvote);

}


/*void
on_btn_M_chercher_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
//declarer les GTKwidget.
	  GtkWidget* inputIDchercher ;//id a chercher
	  GtkWidget* output;
	  GtkWidget* SJ;
	  GtkWidget* SM;
	  GtkWidget* SA;
          GtkWidget* COX;
	  GtkWidget* outputEr;
// associer les objets avec des variables
	inputIDchercher = lookup_widget(button,"entryidliste") ;
//declarer 
        char idch[10];
	int idint=atoi(idch);
	strcpy(idch,gtk_entry_get_text(GTK_ENTRY(inputIDchercher)));
//appel function chercher
	liste LM;
	LM=chercher(idch);
	if(LM.idListe!=-1){

	 GtkSpinButton *SJ=lookup_widget(button, "spinbuttonjourmk");
         gtk_spin_button_set_value(SJ,LM.date_depot.jour);
	 GtkSpinButton *SM=lookup_widget(button, "spinbuttonmoismk");
         gtk_spin_button_set_value(SM,LM.date_depot.mois);
	 GtkSpinButton *SA=lookup_widget(button, "spinbuttonanneemk");
         gtk_spin_button_set_value(SA,LM.date_depot.annee);
	COX=lookup_widget(button,"comboboxorientation");
liste Li;
int tr=0;
     	FILE *g=fopen("liste.txt","r");
while(!tr && fscanf(g,"%d %d %s %d %d %d %d %d %d \n",&Li.idListe,&Li.idtete,Li.orientation,&Li.date_depot.jour,&Li.date_depot.mois,&Li.date_depot.annee,&Li.id1,&Li.id2,&Li.id3)!=EOF)
	{
	if(idint==Li.idListe)
	  { tr=1;   //condition d'arret
	  }
	}
	fclose(g);


	 if(strcmp(LM.orientation,"Centre")){
         	gtk_combo_box_set_active(COX,2);}
	 else if(strcmp(LM.orientation,"Gauche")){
         	gtk_combo_box_set_active(COX,3);}
	 else if(strcmp(LM.orientation,"Droite")){
         	gtk_combo_box_set_active(COX,1);}

	 output=lookup_widget(button,"entryid1");
         gtk_entry_set_text(GTK_ENTRY(output),LM.id1);
	 output=lookup_widget(button,"entryid2");
         gtk_entry_set_text(GTK_ENTRY(output),LM.id2);
	 output=lookup_widget(button,"entryid3");
         gtk_entry_set_text(GTK_ENTRY(output),LM.id3);
}
	else{
	 	
		///
	}
}*/
void
on_btn_M_chercher_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
//declarer les GTKwidget.
	  GtkWidget* inputIDchercher ;//id a chercher
	  GtkWidget* output;
	  GtkWidget* SJ;
	  GtkWidget* SM;
	  GtkWidget* SA;
          GtkWidget* COX;
// associer les objets avec des variables
	inputIDchercher = lookup_widget(button,"entryidliste");
//declarer 
        char idch[50],chidt[50],chid1[50],chid2[50],chid3[50];
	liste LM;
	strcpy(idch,gtk_entry_get_text(GTK_ENTRY(inputIDchercher)));
//appel function chercher_election
	LM=chercher(idch);
	if(LM.idListe!=-1)

	{
	output=lookup_widget(button,"entryidtete");
        sprintf(chidt,"%d",LM.idtete);
         gtk_entry_set_text(GTK_ENTRY(output),chidt);
	 SJ=lookup_widget(button, "spinbuttonjourmk");
         gtk_spin_button_set_value(SJ,LM.date_depot.jour);
	 SM=lookup_widget(button, "spinbuttonmoismk");
         gtk_spin_button_set_value(SM,LM.date_depot.mois);
	 SA=lookup_widget(button, "spinbuttonanneemk");
         gtk_spin_button_set_value(SA,LM.date_depot.annee);
//*************************************
	 COX=lookup_widget(button,"comboboxorientation");
	 if(strcmp(LM.orientation,"Droite")==0){
         	gtk_combo_box_set_active(COX,0);}
	 else if(strcmp(LM.orientation,"Centre")==0){
         	gtk_combo_box_set_active(COX,1);}
	else if(strcmp(LM.orientation,"Gauche")==0){
         	gtk_combo_box_set_active(COX,2);}
	
	 output=lookup_widget(button,"entryid1");
	                sprintf(chid1,"%d",LM.id1);
         gtk_entry_set_text(GTK_ENTRY(output),chid1);
	 output=lookup_widget(button,"entryid2");
		        sprintf(chid2,"%d",LM.id2);
         gtk_entry_set_text(GTK_ENTRY(output),chid2);
	 output=lookup_widget(button,"entryid3");
			 sprintf(chid3,"%d",LM.id3);
         gtk_entry_set_text(GTK_ENTRY(output),chid3);      
//*************************************
}
}


void
on_btn_M_Modifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
//declarer les GTKwidget.
	  GtkWidget* inputIDchercher ;//id 
	  GtkWidget* output;
// associer les objets avec des variables
	inputIDchercher = lookup_widget(button,"entryidliste") ;
//declarer 
        char idch[10],ID1[10],ID2[10],ID3[10],IDT[10];
	int idIN;
	liste nouvL;
	int test;
	strcpy(idch,gtk_entry_get_text(GTK_ENTRY(inputIDchercher)));
//convert txtentry to int 
	idIN=atoi(idch);
	nouvL.idListe=idIN;
	GtkWidget* Jour; 
	GtkWidget* Mois;
	GtkWidget* Annee; 
	GtkWidget* ComboboxO; 
	GtkWidget* idtete ;
	GtkWidget* id1 ;
	GtkWidget* id2 ;
	GtkWidget* id3 ;
// associer les objets avec des variables
	Jour = lookup_widget(button,"spinbuttonjourmk") ;
	Mois = lookup_widget(button,"spinbuttonmoismk") ;
	Annee = lookup_widget(button,"spinbuttonanneemk") ;
	ComboboxO= lookup_widget(button,"comboboxorientation") ;
	idtete = lookup_widget(button,"entryidtete") ;
	id1 = lookup_widget(button,"entryid1") ;
	id2 = lookup_widget(button,"entryid2") ;
	id3 = lookup_widget(button,"entryid3") ;
// récupérer les valeurs des spin buttons 
	
	nouvL.date_depot.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
	nouvL.date_depot.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
	nouvL.date_depot.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));

//recupérer lcombo
	strcpy(nouvL.orientation,gtk_combo_box_get_active_text(GTK_COMBO_BOX (ComboboxO)));
// récupérer les valeurs de champ txt 
 strcpy(IDT,gtk_entry_get_text(GTK_ENTRY(idtete)));
nouvL.idtete=atoi(IDT);
	
	strcpy(ID1,gtk_entry_get_text(GTK_ENTRY(id1)));
nouvL.id1=atoi(ID1);
	strcpy(ID2,gtk_entry_get_text(GTK_ENTRY(id2)));
nouvL.id2=atoi(ID2);
	strcpy(ID3,gtk_entry_get_text(GTK_ENTRY(id3)));
nouvL.id3=atoi(ID3);

		//appel function modifier

	        test= modifier("liste.txt",idIN,nouvL);;
		if(test==1){
		 //...........................................ltree view 
			GtkWidget *modif;
			GtkWidget *affich;
			modif=lookup_widget(button,"windowmodifliste");
			gtk_widget_hide(modif);
			affich=create_windowaffichageliste();
			gtk_widget_show (affich);	
		}
		
}
/*
void
on_btn_M_Modifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{char jour[50];
char mois[50];
char annee[50];
int j,m,a;
liste l1;
GtkWidget *idt ,*id1,*id2,*id3, *orientation ,*jour, *mois, *annee;


id1=lookup_widget(button,"entryid1");
id2=lookup_widget(button,"entryid2");
id3=lookup_widget(button,"entryid3");
idt=lookup_widget(button,"entryidtete");
orientation=lookup_widget(button,"comboboxorientation");
jour=lookup_widget(button,"spinbuttonjourmk");
mois=lookup_widget(button,"spinbuttonmoismk");
annee=lookup_widget(button,"spinbuttonanneemk");
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));


sprintf(jour,"%d",j);
sprintf(mois,"%d",m);
sprintf(annee,"%d",a);

strcpy(l1.idtete,gtk_entry_get_text(GTK_ENTRY(idt)));
strcpy(l1.id1,gtk_entry_get_text(GTK_ENTRY(id1)));
strcpy(l1.id2,gtk_entry_get_text(GTK_ENTRY(id2)));
strcpy(l1.id3,gtk_entry_get_text(GTK_ENTRY(id3)));
strcpy(l1.orientation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(orientation)));


strcpy(l1.date_depot.jour,jour);
strcpy(l1.date_depot.mois,mois);
strcpy(l1.date_depot.annee,annee);
supprimer_liste(l)
ajouter("liste.txt",l1);

}
}
*/

void
on_buttonconfirmerajout_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
//declarer les GTKwidget.
	int x;
        char IDL[20],IDT[20],ID1[20],ID2[20],ID3[20];
	GtkWidget* Jour; //spinbuttun pour le choix du jour.
	GtkWidget* Mois; //spinbuttun pour Le choix du mois.
	GtkWidget* Annee; //spinbuttun pour le choix de l'année.
	GtkWidget* ComboboxO; //comobox  ORIENTATION
	GtkWidget* idl ; //ID liste
        GtkWidget* idt ; //ID TETE
	GtkWidget* id1 ;
	GtkWidget* id2 ;
	GtkWidget* id3 ;
	//declarer la struct
        liste L;
	// associer les objets avec des variables
        Jour = lookup_widget(button,"spinbutton37") ;
	Mois = lookup_widget(button,"spinbutton39") ;
	Annee = lookup_widget(button,"spinbutton38") ;
	ComboboxO = lookup_widget(button,"combobox15") ;
	idl = lookup_widget(button,"entry122") ;
	idt = lookup_widget(button,"entry125") ;
	id1 = lookup_widget(button,"entry126") ;
	id2 = lookup_widget(button,"entry123") ;
	id3 = lookup_widget(button,"entry124") ;
	// récupérer les valeurs des spin buttons 
	L.date_depot.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
	L.date_depot.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
	L.date_depot.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
//recupérer lcombo
	strcpy(L.orientation ,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ComboboxO)));
// récupérer les valeurs de champ txt 
        strcpy(IDL,gtk_entry_get_text(GTK_ENTRY(idl)));
L.idListe=atoi(IDL);
	strcpy(IDT,gtk_entry_get_text(GTK_ENTRY(idt)));
L.idtete=atoi(IDT);
	strcpy(ID1,gtk_entry_get_text(GTK_ENTRY(id1)));
L.id1=atoi(ID1);
	strcpy(ID2,gtk_entry_get_text(GTK_ENTRY(id2)));
L.id2=atoi(ID2);
	strcpy(ID3,gtk_entry_get_text(GTK_ENTRY(id3)));
L.id3=atoi(ID3);
//appel de la function ajouter
x=ajouter("liste.txt",L);	
GtkWidget *windowaffichageliste;//f1
  GtkWidget *windowajoutliste;//f2
windowaffichageliste = create_windowaffichageliste ();
  gtk_widget_show (windowaffichageliste);
windowajoutliste = create_windowajoutliste ();
    gtk_widget_hide (windowajoutliste);				
}


void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  int x ;
  char id[50];
  liste L;
  GtkWidget *idrechsuppmk;
   idrechsuppmk=lookup_widget(button,"entryidrechsuppmk");	
   strcpy(id,gtk_entry_get_text(GTK_ENTRY(idrechsuppmk)));
   L.idListe=atoi(id);
   x=supprimer("liste.txt",L.idListe);
  GtkWidget *windowaffichageliste;//f2
  GtkWidget *windowrechsupp;//f2
  windowaffichageliste = create_windowaffichageliste ();
  gtk_widget_show (windowaffichageliste);
  windowrechsupp = create_windowrechsupp();
      gtk_widget_hide (windowrechsupp);				
}


void
on_treeviewaffichage_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
}
/*
void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)

{	GtkWidget *treeview1_M ;
	GtkWidget *cherch;
	char ch[20];
	treeview1_M=lookup_widget(button,"treeviewaffichage");
	cherch = lookup_widget (button,"entryrech");
	strcpy(ch, gtk_entry_get_text(GTK_ENTRY(cherch)));
	Chercher_entrymariem(treeview1_M,ch);

}*/
//***********************BTN CHERCHERRR
void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{ char s[20];
liste l;
GtkWidget *treeviewaffichage, *entryrech, *windowaffichageliste;
entryrech = lookup_widget(button, "entryrech") ;
strcpy(s,gtk_entry_get_text(GTK_ENTRY(entryrech)));
FILE *f=NULL;
FILE *f1=NULL;

f=fopen("liste.txt","r");
f1=fopen("liste1.txt","w");

 while(fscanf(f,"%d %d %s %d %d %d %d %d %d \n",&l.idListe,&l.idtete,l.orientation,&l.date_depot.jour,&l.date_depot.mois,&l.date_depot.annee,&l.id1,&l.id2,&l.id3)!=EOF){
  if (strcmp(s,l.orientation)==0){
       fprintf(f1,"%d %d %s %d %d %d %d %d %d \n",l.idListe,l.idtete,l.orientation,l.date_depot.jour,l.date_depot.mois,l.date_depot.annee,l.id1,l.id2,l.id3);

}
}
fclose(f);
fclose(f1);

windowaffichageliste = lookup_widget(button,"windowaffichageliste");
  gtk_widget_hide (windowaffichageliste);
windowaffichageliste=lookup_widget(GTK_WIDGET(button),"windowaffichageliste");
  windowaffichageliste = create_windowaffichageliste();
  gtk_widget_show (windowaffichageliste);
  treeviewaffichage=lookup_widget(windowaffichageliste,"treeviewaffichage");
  //afficher_cher_mariem(treeviewaffichage); 
 afficher(treeviewaffichage);
  remove("liste1.txt");
}
//******************************END
void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowaffichageliste, *treeviewaffichage ;

  windowaffichageliste = lookup_widget(button,"windowaffichageliste");

  gtk_widget_hide (windowaffichageliste);
  windowaffichageliste=lookup_widget(GTK_WIDGET(button),"windowaffichageliste");
  windowaffichageliste= create_windowaffichageliste();
  gtk_widget_show (windowaffichageliste);
  treeviewaffichage=lookup_widget(windowaffichageliste,"treeviewaffichage");
  afficher(treeviewaffichage);
}


void
on_buttonvotevote_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}

