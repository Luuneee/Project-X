#ifndef POINT_H_INCLUDED
#define POINT_H_INCLUDED
#include <stdio.h>


typedef struct
{
    int id;
    char typerec [30];
    int id_liste;
    int nbv;
    char textrec [200];
} rec;


int ajouterrec(char * reclamation, rec r );
int modifierrec( char * reclamation, int id, rec nouv );
int supprimerrec(char * reclamation, int id);
rec chercherrec(char * reclamation, int id);
#endif // POINT_H_INCLUDED
