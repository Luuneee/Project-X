#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"

#include "election.c"
#include "reclamation.c"
#include "reclamation.h"
#include "fonctions.c"

int genre=1;
int genre1=1;

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *mod7, *mod8, *mod9, *mod10, *mod11, *mod12, *mod13, *mod14, *pInfo;
election p;
int a=0;
int id;
char conseillers[20];
FILE *f;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
mod7=lookup_widget(objet,"mod7");
mod8=lookup_widget(objet,"mod8");
mod9=lookup_widget(objet,"mod9");
mod10=lookup_widget(objet,"mod10");
mod11=lookup_widget(objet,"mod11");
mod12=lookup_widget(objet,"mod12");
mod13=lookup_widget(objet,"mod13");
mod14=lookup_widget(objet,"mod14");
id = atoi(gtk_entry_get_text(GTK_ENTRY(mod4)));
f = fopen("election.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %d %s %d %d %d %d\n",&(p.id),&(p.habitants),p.municipalite,&(p.conseillers),&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
	{
		if(id==p.id){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
sprintf(conseillers,"%d",p.conseillers);
gtk_entry_set_text(GTK_ENTRY(mod3),p.municipalite);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mod1),p.d.j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mod2),p.d.m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mod3),p.d.a);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod5),p.habitants==0?TRUE:FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod6),p.habitants==1?TRUE:FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod7),p.habitants==2?TRUE:FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod8),p.habitants==3?TRUE:FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod9),p.habitants==4?TRUE:FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod10),p.habitants==5?TRUE:FALSE);
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod11),p.habitants==6?TRUE:FALSE);
gtk_entry_set_text(GTK_ENTRY(mod12),p.municipalite);
gtk_entry_set_text(GTK_ENTRY(mod13),conseillers);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Election introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *mod7, *mod8, *mod9, *mod10, *mod11, *mod12, *mod13, *mod14, *pInfo;
election u;
char* ch = (char *) malloc(500);
strcpy(ch,"");
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
mod7=lookup_widget(objet,"mod7");
mod8=lookup_widget(objet,"mod8");
mod9=lookup_widget(objet,"mod9");
mod10=lookup_widget(objet,"mod10");
mod11=lookup_widget(objet,"mod11");
mod12=lookup_widget(objet,"mod12");
mod13=lookup_widget(objet,"mod13");
mod14=lookup_widget(objet,"mod14");
bool a=gtk_toggle_button_get_active(GTK_CHECK_BUTTON(mod14));
if(strcmp(gtk_entry_get_text(GTK_ENTRY(mod12)),"")==0)
strcat(ch,"Veuillez écrire la municipalité\n");
if(strcmp(gtk_entry_get_text(GTK_ENTRY(mod13)),"")==0)
strcat(ch,"Veuillez écrire le nombre de conseillers\n");
if(!a)
strcat(ch,"Veuillez confirmer");
if(strcmp(ch,"")==0){
u.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod4)));
strcpy(u.municipalite,gtk_entry_get_text(GTK_ENTRY(mod12)));
u.d.j=gtk_spin_button_get_value(GTK_SPIN_BUTTON(mod1));
u.d.m=gtk_spin_button_get_value(GTK_SPIN_BUTTON(mod2));
u.d.a=gtk_spin_button_get_value(GTK_SPIN_BUTTON(mod3));
u.habitants=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mod5))?0:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mod6))?1:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mod7))?2:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mod8))?3:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mod9))?4:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(mod10))?5:6;
u.conseillers=atoi(gtk_entry_get_text(GTK_ENTRY(mod13)));
modifier(u,"election.txt");
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	guint id;
	GtkWidget *pInfo, *objet, *af;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cette élection?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer(id,"election.txt");
	afficher(treeview,"election.txt","","","");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;
}	
}
}


void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af;
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeview");
afficher(treeview,"election.txt", "","","");
af = lookup_widget(objet,"af");
gtk_widget_hide (af);
}


void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6, *aj7, *aj8, *aj9, *aj10, *aj11, *aj12, *aj13, *aj14, *pInfo;
election u;
char *ch = (char *) malloc(500);
strcpy(ch,"");
aj1=lookup_widget(objet,"aj1");
aj2=lookup_widget(objet,"aj2");
aj3=lookup_widget(objet,"aj3");
aj4=lookup_widget(objet,"aj4");
aj5=lookup_widget(objet,"aj5");
aj6=lookup_widget(objet,"aj6");
aj7=lookup_widget(objet,"aj7");
aj8=lookup_widget(objet,"aj8");
aj9=lookup_widget(objet,"aj9");
aj10=lookup_widget(objet,"aj10");
aj11=lookup_widget(objet,"aj11");
aj12=lookup_widget(objet,"a12");
aj13=lookup_widget(objet,"aj13");
aj14=lookup_widget(objet,"aj14");
bool a=gtk_toggle_button_get_active(GTK_CHECK_BUTTON(aj14));
if(strcmp(gtk_entry_get_text(GTK_ENTRY(aj4)),"")==0)
strcat(ch,"Veuillez écrire l'id\n");
if(strcmp(gtk_entry_get_text(GTK_ENTRY(aj12)),"")==0)
strcat(ch,"Veuillez écrire la municipalité\n");
if(strcmp(gtk_entry_get_text(GTK_ENTRY(aj13)),"")==0)
strcat(ch,"Veuillez écrire le nombre de conseillers\n");
if(!a)
strcat(ch,"Veuillez confirmer");
if(strcmp(ch,"")==0){
u.id=atoi(gtk_entry_get_text(GTK_ENTRY(aj4)));
strcpy(u.municipalite,gtk_entry_get_text(GTK_ENTRY(aj12)));
u.d.j=gtk_spin_button_get_value(GTK_SPIN_BUTTON(aj1));
u.d.m=gtk_spin_button_get_value(GTK_SPIN_BUTTON(aj2));
u.d.a=gtk_spin_button_get_value(GTK_SPIN_BUTTON(aj3));
u.habitants=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(aj5))?0:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(aj6))?1:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(aj7))?2:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(aj8))?3:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(aj9))?4:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(aj10))?5:6;
u.conseillers=atoi(gtk_entry_get_text(GTK_ENTRY(aj13)));
ajouter(u,"election.txt");
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,ch);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj, *af;
aj=lookup_widget(objet,"aj");
aj=create_aj();
gtk_widget_show(aj);
af = lookup_widget(objet,"af");
gtk_widget_hide (af);
}


void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj, *af;
aj=lookup_widget(objet,"mod");
aj=create_mod();
gtk_widget_show(aj);
af = lookup_widget(objet,"af");
gtk_widget_hide (af);
}


void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af, *e1, *e2, *e3;
char date[20], municipalite[20], id[10];
af=lookup_widget(objet,"af");
treeview=lookup_widget(af,"treeview");
e1=lookup_widget(objet, "entry1");
e2=lookup_widget(objet, "entry2");
e3=lookup_widget(objet, "entry3");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(e1)));
strcpy(municipalite,gtk_entry_get_text(GTK_ENTRY(e2)));
strcpy(date,gtk_entry_get_text(GTK_ENTRY(e3)));
afficher(treeview, "election.txt", id, municipalite, date);
}


void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *pInfo;
char ch[100];
float x = TPE("user.txt");
sprintf(ch, "Taux de participation : %.2f", x);
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,ch);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_button15_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *pInfo;
char *ch = TPHF("user.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,ch);
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_button16_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj , * af ;
	
	aj = lookup_widget(objet,"aj");
	gtk_widget_destroy(aj);
	af=create_af();
	gtk_widget_show(af);
}


void
on_button17_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod , * af ;
	
	mod = lookup_widget(objet,"mod");
	gtk_widget_destroy(mod);
	af=create_af();
	gtk_widget_show(af);
}


void
on_buttonespacereclamation_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget * GestionReclamationFedi;
GtkWidget * General ;

GestionReclamationFedi= create_GestionReclamationFedi ();
gtk_widget_show (GestionReclamationFedi);
General = lookup_widget(button,"General");
gtk_widget_hide (General);
}


void
on_buttonafficherfedi_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionReclamationFedi,*treeviewfedi ;

GestionReclamationFedi = lookup_widget(button,"GestionReclamationFedi");

  gtk_widget_hide (GestionReclamationFedi);
GestionReclamationFedi=lookup_widget(GTK_WIDGET(button),"GestionReclamationFedi");
  GestionReclamationFedi = create_GestionReclamationFedi();



  gtk_widget_show (GestionReclamationFedi);
  treeviewfedi=lookup_widget(GestionReclamationFedi,"treeviewfedi");

  afficher_reclamation(treeviewfedi);
}


void
on_buttonmodifierfedi_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget * Fedimodifer;
GtkWidget * GestionReclamationFedi ;

Fedimodifer= create_Fedimodifer ();
gtk_widget_show (Fedimodifer);
GestionReclamationFedi = lookup_widget(button,"GestionReclamationFedi");
gtk_widget_hide (GestionReclamationFedi);
}


void
on_buttonajouterfedi_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget * FediAjouter;
GtkWidget * GestionReclamationFedi ;

FediAjouter= create_FediAjouter ();
gtk_widget_show (FediAjouter);
GestionReclamationFedi = lookup_widget(button,"GestionReclamationFedi");
gtk_widget_hide (GestionReclamationFedi);
}


void
on_buttonsupprime_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

	int v,x ;
	char as[200];
	int id;
	rec r;
	GtkWidget * entryentry;
	GtkWidget * labellabel;
	
	
	
	entryentry = lookup_widget(objet,"entryentry");
	labellabel = lookup_widget(objet,"labellabel");

	strcpy(as,gtk_entry_get_text(GTK_ENTRY(entryentry)));
	id=atoi(as);
	

	x=supprimerrec("reclamation.txt",id);
	if (x==1)
		gtk_label_set_text(GTK_LABEL(labellabel),"suppression avec succés");
		
		
	else 
		gtk_label_set_text(GTK_LABEL(labellabel),"id introuvable");
}


void
on_buttonrechercherfedi_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{


char s[20];
int id;
rec r;
GtkWidget* treeviewfedi;
GtkWidget* entryentry;
GtkWidget* GestionReclamationFedi;


entryentry = lookup_widget(button, "entryentry") ;
strcpy(s,gtk_entry_get_text(GTK_ENTRY(entryentry)));
id=atoi(s);
FILE *f=NULL;
FILE *f1=NULL;

f=fopen("reclamation.txt","r");
f1=fopen("reclamation1.txt","w");

 while(fscanf(f, "%d %s %d %d %s\n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF){
  if (r.id==id ||r.id_liste==id ||r.nbv==id){
       fprintf(f1, "%d %s %d %d %s\n",r.id,r.typerec,r.id_liste,r.nbv,r.textrec);

}
}
fclose(f);
fclose(f1);

GestionReclamationFedi = lookup_widget(button,"GestionReclamationFedi");

  gtk_widget_hide (GestionReclamationFedi);
  GestionReclamationFedi=lookup_widget(GTK_WIDGET(button),"GestionReclamationFedi");
  GestionReclamationFedi = create_GestionReclamationFedi();

  gtk_widget_show (GestionReclamationFedi);
  treeviewfedi=lookup_widget(GestionReclamationFedi,"treeviewfedi");
  afficher_recherche(treeviewfedi); 
  remove("reclamation1.txt");
}


void
on_buttonretourfedi_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget * FediAjouter;
GtkWidget * GestionReclamationFedi ;

GestionReclamationFedi= create_GestionReclamationFedi ();
gtk_widget_show (GestionReclamationFedi);
FediAjouter = lookup_widget(button,"FediAjouter");
gtk_widget_hide (FediAjouter);
}


void
on_buttonajoutreclamationfedi_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
int v,w,x,y ;
	char I[50];
	char LE[50];
	char NB[50];
	rec r ;
	GtkWidget * entryidrec, *comboboxentry5, *entrylistel, *entrynbv, * entrytextrec, * label228, *radiobutton6, *radiobutton7; 
	GtkWidget *FediAjouter;
	FediAjouter = lookup_widget(GTK_WIDGET(button),"FediAjouter");
	
	
	entryidrec = lookup_widget(GTK_WIDGET(button),"entryidrec");
	comboboxentry5=lookup_widget(GTK_WIDGET(button),"comboboxentry5");
	entrylistel=lookup_widget(GTK_WIDGET(button),"entrylistel");
	entrynbv=lookup_widget(GTK_WIDGET(button),"entrynbv");
	entrytextrec=lookup_widget(GTK_WIDGET(button),"entrytextrec");
	label228=lookup_widget(button,"label228");
	
	strcpy(I,gtk_entry_get_text(GTK_ENTRY(entryidrec)));
	v=atoi(I);
	r.id=v;
	strcpy(r.typerec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry5)));
	strcpy(LE,gtk_entry_get_text(GTK_ENTRY(entrylistel)));	
	w=atoi(LE);
	r.id_liste=w;
	strcpy(NB,gtk_entry_get_text(GTK_ENTRY(entrynbv)));
	y=atoi(NB);
	r.nbv=y;
	strcpy(r.textrec,gtk_entry_get_text(GTK_ENTRY(entrytextrec)));

	

	/*spinbutton==>Conseillers
	spinbutton11=lookup_widget(objet,"spinbutton11");
	b.ID_Bv=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton11));
	spinbutton9=lookup_widget(objet,"spinbutton9");
	b.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton9));
	spinbutton5=lookup_widget(objet,"spinbutton5");
	b.capacite_obs=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton5));
	spinbutton14=lookup_widget(objet,"spinbutton14");
	b.capacite_elec=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton14));*/
	
	
	
	x=ajouterrec("reclamation.txt",r);
	if (x==1)
		gtk_label_set_text(GTK_LABEL(label228),"Ajout avec succés");
	else 
		gtk_label_set_text(GTK_LABEL(label228),"echec d'ajout");

}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ int x;
if(gtk_toggle_button_get_active(togglebutton)){
		x=1;
	}
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
int x;
if(gtk_toggle_button_get_active(togglebutton)){
		x=2;
	}
}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget * GestionReclamationFedi;
GtkWidget * General ;

General= create_General ();
gtk_widget_show (General);
GestionReclamationFedi = lookup_widget(button,"GestionReclamationFedi");
gtk_widget_hide (GestionReclamationFedi);
}


void
on_Bouttonmodifierreclamationfedi_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *entry30, *comboboxentry6 , *entry32 , *entry33 , *entry34,  *labels ;
	
	char message[200];
	

	int id;
	rec r;
	rec nouv;
	char I[50];
	char LE[50];
	char NB[50];
	int v,w,x,y ;
	entry30=lookup_widget(button,"entry30");
	comboboxentry6=lookup_widget(button,"comboboxentry6");
	entry32=lookup_widget(button,"entry32");
	entry33 = lookup_widget(button,"entry33");
        entry34 = lookup_widget(button,"entry34");
	labels = lookup_widget(button,"labels");



	strcpy(I,gtk_entry_get_text(GTK_ENTRY(entry30)));
	v=atoi(I);
	nouv.id=v;
	strcpy(nouv.typerec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry6)));
	strcpy(LE,gtk_entry_get_text(GTK_ENTRY(entry32)));
	w=atoi(LE);
	nouv.id_liste=w;
	strcpy(NB,gtk_entry_get_text(entry33));
	v=atoi(NB);
	nouv.nbv=v;
	strcpy(nouv.textrec,gtk_entry_get_text(GTK_ENTRY(entry34)));
	
	x=modifierrec( "reclamation.txt", nouv.id, nouv);
	if (x==1)
		{sprintf(message,"Votre modification a été effectué avec succés ! ");
		gtk_label_set_text(GTK_LABEL(labels),message);}
	else 
		sprintf(message,"ID non existant ! ");
		gtk_label_set_text(GTK_LABEL(labels),message);
	

}


void
on_buttonretourmodiffedi_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * Fedimodifer;
GtkWidget * GestionReclamationFedi ;

GestionReclamationFedi= create_GestionReclamationFedi ();
gtk_widget_show (GestionReclamationFedi);
Fedimodifer = lookup_widget(button,"Fedimodifer");
gtk_widget_hide (Fedimodifer);
}


void
on_buttonstateretour_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * statistiquereclamation;
GtkWidget * GestionReclamationFedi;

GestionReclamationFedi= create_GestionReclamationFedi ();
gtk_widget_show (GestionReclamationFedi);
statistiquereclamation = lookup_widget(button,"statistiquereclamation");
gtk_widget_hide (statistiquereclamation);

}


void
on_buttonsubmit_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget* entrylistelecto, *labelnbrlist;
GtkWidget *statistiquereclamtion ;
 int s, id;	
 int h[20];
 int f[20];

  statistiquereclamtion =lookup_widget(button, "statistiquereclamtion" );
  entrylistelecto = lookup_widget(button, "entrylistelecto") ;
  labelnbrlist=lookup_widget(button,"labelnbrlist");

  strcpy(f,gtk_entry_get_text(GTK_ENTRY(entrylistelecto)));
  id=atoi(f);
	
  s=nombre_rec_parliste(id);

  sprintf(h,"%d",s);
  gtk_label_set_text(GTK_LABEL(labelnbrlist),h); 
}


void
on_Statistique_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget * statistiquereclamation;
GtkWidget * GestionReclamationFedi;

statistiquereclamation= create_statistiquereclamation ();
gtk_widget_show (statistiquereclamation);
GestionReclamationFedi = lookup_widget(button,"GestionReclamationFedi");
gtk_widget_hide (GestionReclamationFedi);


}


void
on_buttontotrec_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

int s;
char h[20];
GtkWidget * labelnbr, *buttontotrec;

buttontotrec =lookup_widget(button, "buttontotrec" );
labelnbr=lookup_widget(button,"labelnbr");

s=nombre_reclamation();
sprintf(h,"%d",s);
gtk_label_set_text(GTK_LABEL(labelnbr),h);
}

                                      


void
on_buttonespaceelection_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget * General;
GtkWidget * af ;

af= create_af ();
gtk_widget_show (af);
General = lookup_widget(button,"General");
gtk_widget_hide (General);
}






void
on_buttonyahyaajouteraa_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *NOM ,*PRENOM , *spinjour , *spinmois , *spinannee,*NUM_TEL , *ADRESSE , *CIN, *LOGIN , *MDP , *ROLE  ,*NBR_BV, *VOTE ,*fenetre_ajout ,*radiobutton1 ,*radiobutton2;
	utilisateur u;
	//Nom
	NOM = lookup_widget(button,"entry_nom_ajt_yahya");
	strcpy(u.Nom,gtk_entry_get_text(GTK_ENTRY(NOM)));
	//Prenom
	PRENOM = lookup_widget(button,"entry_ajout_prenom_yahya");
	strcpy(u.Prenom,gtk_entry_get_text(GTK_ENTRY(PRENOM)));
	//jour
	spinjour = lookup_widget(button,"spinajout_jrs_yahya");
	u.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinjour));
	///mois
	spinmois = lookup_widget(button,"spinajout_mois_yahya");
	u.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinmois));
	//annee
	spinannee = lookup_widget(button,"spinajout_annee_yahya");
	u.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinannee));
	//tel
	NUM_TEL = lookup_widget(button,"entry_tel_ajout_yahya");
	u.tel=atoi(gtk_entry_get_text(GTK_ENTRY(NUM_TEL)));
	//adresse
	ADRESSE = lookup_widget(button,"entry_ajout_adresse_yahya");
	strcpy(u.Adresse,gtk_entry_get_text(GTK_ENTRY(ADRESSE)));
	//Cin
	CIN = lookup_widget(button,"entry_ajout_cin_yahya");
	u.CIN=atoi(gtk_entry_get_text(GTK_ENTRY(CIN)));
	//login
	LOGIN = lookup_widget(button,"entry_ajout_login_yahya");
	strcpy(u.Login,gtk_entry_get_text(GTK_ENTRY(LOGIN)));
	//mdp
	MDP = lookup_widget(button,"entry_ajout_mdp_yahya");
	strcpy(u.mdp,gtk_entry_get_text(GTK_ENTRY(MDP)));
	//role 
	ROLE = lookup_widget(button,"combo_ajout_role_yahya");
	strcpy(u.Role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ROLE)));
	//nbr bv
	NBR_BV = lookup_widget(button,"spin_ajout_nbr_yahya");
	u.nbr_bv=atoi(gtk_entry_get_text(GTK_ENTRY(NBR_BV)));
	//vote 
	VOTE = lookup_widget(button,"spin_ajout_vote_yahya");
	u.Vote=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(VOTE));

	/*//Sexe
	radiobutton1 = lookup_widget(button,"radio_homme_adam_aj");
	radiobutton2 = lookup_widget(button,"radio_femme_adam_aj");
	if (genre==1)
		strcpy(u.Sexe,"homme");
	else 
		strcpy(u.Sexe,"femme");*/

	ajouter_adamy(u);
}


void
on_radio_femme_adam_aj_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
	genre=2;
}



void
on_buttonretouryahyaaa_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_gestion;
fenetre_ajout = lookup_widget(button,"windowajouteradam");
gtk_widget_hide(fenetre_ajout);
fenetre_gestion = lookup_widget(button,"windowajouteradam");
fenetre_gestion = create_windowgestionadam();
gtk_widget_show(fenetre_gestion);
}


void
on_radiobuttonyahyahomme_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
	genre=1;
}


void
on_treeview_adam_gestion__row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *nom;
	gchar *prenom;
	gchar *sexe;
	gint *jour;
	gint *mois;
	gint *annee;
	gint *tel;
	gint *cin;
	gchar *adresse;
	gchar *login;
	gchar *mdp;
	gchar *role;
	gint *nbr;
	gint *vote;
	utilisateur u;
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path))
		{
		//obtention des valeurs de la ligne selectionnee
		gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&nom,1,&prenom,2,&sexe,3,&jour,4,&mois,5,&annee,6,&tel,7,&cin,8,&adresse,9,&login,10,&mdp,11,&role,12,&nbr,13,&vote,-1);
		//copie des valeurs de la var u de type utilisateur pour le passer a la fct de supp 
		strcpy(u.Nom,nom);
		strcpy(u.Prenom,prenom);
		strcpy(u.Sexe,sexe);
		u.jour=jour;
		u.mois=mois;
		u.annee=annee;
		u.tel=tel;
		u.CIN=cin;
		strcpy(u.Adresse,adresse);
		strcpy(u.Login,login);
		strcpy(u.mdp,mdp);
		strcpy(u.Role,role);
		u.nbr_bv=nbr;
		u.Vote=vote;
		// appel de la fct de supp
		//supprimer_adamy(u);
		//mise a jrs de la treeview
		afficher_adamy(treeview,"utilisateur.txt");
		}
}
void
on_treeview_recher_yahya_gestion_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *Noms;
gchar *Prenoms;
gchar *Sexes;
gint *jours;
gint *moiss;
gint *annees;
gint *tels;
gchar *Adresses;
gint *CINs;
gchar *Logins;
gchar *mdps;
gchar *Roles;
gint *nbr_bvs;
gint *Votes;
utilisateur u;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model, &iter, path)) {
	gtk_tree_model_get(GTK_LIST_STORE(model), &iter,0,&Noms,1,&Prenoms,2,&Sexes,3,&jours,4,&moiss,5,&annees,6,&tels,7,&Adresses,8,&CINs,9,&Logins,10,&mdps,11,&Roles,12,&nbr_bvs,13,&Votes,-1);
	strcpy(u.Nom,Noms);
	strcpy(u.Prenom,Prenoms);
	strcpy(u.Sexe,Sexes);
	u.jour=jours;
	u.mois=moiss;
	u.annee=annees;
	u.tel=tels;
	strcpy(u.Adresse,Adresses);
	u.CIN=CINs;
	strcpy(u.Login,Logins);
	strcpy(u.mdp,mdps);
	strcpy(u.Role,Roles);
	u.nbr_bv=nbr_bvs;
	u.Vote=Votes;
	//supprimer_adamy(u);	
	//afficher(treeview,"liste.txt");
	afficher_adamy(treeview,"utilisateur.txt");
	

}
}


void
on_btn_ajouter_yahya_gestion_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_gestion;
fenetre_gestion = lookup_widget(button,"windowgestionadam");
gtk_widget_hide(fenetre_gestion);
fenetre_ajout = lookup_widget(button,"windowajouteradam");
fenetre_ajout = create_windowajouteradam();
gtk_widget_show(fenetre_ajout);
}


void
on_btn_supp_yahya_gestion_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *fenetre_gestion;//f2
  GtkWidget *fenetre_CINS;//f2
  //CINSUPP=lookup_widget(button,"entry4CINpoursuppadam");
  fenetre_gestion = lookup_widget(button,"windowgestionadam");	
  fenetre_gestion = create_windowgestionadam();
  gtk_widget_hide (fenetre_gestion);
  //x=supprimer_adamy("utilisateur.txt",u.CIN);
  gtk_widget_show (fenetre_gestion);
  fenetre_CINS = create_windowsupprimeradam();
  gtk_widget_show (fenetre_CINS);
}


void
on_btn_modif_gestion_yahya_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur u ;
GtkWidget *fentremodif, *fenetre_gestion;


fenetre_gestion = lookup_widget(button,"GestionutilisateurAdemY");
gtk_widget_hide(fenetre_gestion);
fentremodif = lookup_widget(button,"windowmodifadam");
fentremodif = create_windowmodifadam();
gtk_widget_show(fentremodif);
}


void
on_btn_retour_gestion_adam_acc_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_gestion, *fenetre_Acc;
fenetre_gestion = lookup_widget(button,"windowgestionadam");
gtk_widget_hide(fenetre_gestion);
fenetre_Acc = lookup_widget(button,"General");
fenetre_Acc = create_General();
gtk_widget_show(fenetre_Acc);
}


void
on_btn_calcul_gestion_yahya_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowgestionadam, *windowstatistique;
windowgestionadam = lookup_widget(button,"windowgestionadam");
gtk_widget_hide(windowgestionadam);
windowgestionadam = lookup_widget(button,"windowstatistique");
windowstatistique = create_windowstatistique();
gtk_widget_show(windowstatistique);
}


void
on_btn_recher_yahya_gestion_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur u ;
utilisateur A;
char ROLE[30] ;
GtkWidget *entryidadamges;
GtkWidget *treeview_affich;
GtkWidget *treeview_cherch;
entryidadamges=lookup_widget(button,"entry_cin_yahya_gestion");
strcpy(ROLE,gtk_entry_get_text(GTK_ENTRY(entryidadamges)));

A=rechercher_adamy( ROLE);
treeview_cherch=lookup_widget(button,"treeview_recher_yahya_gestion");
afficher_adamy(treeview_cherch,"find.txt");
treeview_affich=lookup_widget(button,"treeview_adam_gestion_");
afficher_adamy(treeview_affich,"liste.txt");
}


void
on_btn_affi_yahya_gestion_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeView *treeview_affich;
treeview_affich=lookup_widget(button,"treeview_adam_gestion_");
afficher_adamy(treeview_affich,"utilisateur.txt");
}


void
on_button_retour_modif_ges_y_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fentremodif, *fenetre_gestion;


fentremodif = lookup_widget(button,"windowmodifadam");
gtk_widget_hide(fentremodif);
fenetre_gestion = lookup_widget(button,"windowgestionadam");
fenetre_gestion = create_windowgestionadam();
gtk_widget_show(fenetre_gestion);
}


void
on_radio_homme_modif_yahyaa_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
	genre1=1;
}


void
on_radio_femme_modif_yahya_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
	genre1=2;
}


void
on_btn_modif_c_yahya_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *NOM ,*PRENOM , *spinjour , *spinmois , *spinannee,*NUM_TEL , *ADRESSE , *CIN, *LOGIN , *MDP , *ROLE  ,*NBR_BV, 			*VOTE ,*fenetre_ajout ,*radiobutton1 ,*radiobutton2;
	int cin,x;
	utilisateur nouv;
	//Nom
	NOM = lookup_widget(button,"entry_nom_modif_yahya");
	strcpy(nouv.Nom,gtk_entry_get_text(GTK_ENTRY(NOM)));
	//Prenom
	PRENOM = lookup_widget(button,"entry_prenom_modif_yahya");
	strcpy(nouv.Prenom,gtk_entry_get_text(GTK_ENTRY(PRENOM)));
	//jour
	spinjour = lookup_widget(button,"spin_jr_modif_yahya");
	nouv.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinjour));
	//mois
	spinmois = lookup_widget(button,"spin_mois_modif_yahya");
	nouv.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinmois));
	//annee
	spinannee = lookup_widget(button,"spin_annee_modif_yahyaa");
	nouv.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinannee));
	//tel
	NUM_TEL = lookup_widget(button,"entry_tel_modif_yahya");
	nouv.tel=atoi(gtk_entry_get_text(GTK_ENTRY(NUM_TEL)));
	//adresse
	ADRESSE = lookup_widget(button,"entry_adresse_modif_yahya");
	strcpy(nouv.Adresse,gtk_entry_get_text(GTK_ENTRY(ADRESSE)));
	//Cin
	CIN = lookup_widget(button,"entry_cin_modif_yahya");
	nouv.CIN=atoi(gtk_entry_get_text(GTK_ENTRY(CIN)));
	cin = nouv.CIN;
	//login
	LOGIN = lookup_widget(button,"entry_login_modif_yahhya");
	strcpy(nouv.Login,gtk_entry_get_text(GTK_ENTRY(LOGIN)));
	//mdp
	MDP = lookup_widget(button,"entry_mdp_modif_yahya");
	strcpy(nouv.mdp,gtk_entry_get_text(GTK_ENTRY(MDP)));
	//role 
	ROLE = lookup_widget(button,"combo_role_modif_yahya");
	strcpy(nouv.Role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ROLE)));
	//nbr bv
	//NBR_BV = lookup_widget(button,"spin_nbr_modif_yahya");
	//nouv.nbr_bv=atoi(gtk_entry_get_text(GTK_ENTRY(NBR_BV)));
	//vote 
	VOTE = lookup_widget(button,"spin_vote_modif_yahya");
	nouv.Vote=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(VOTE));

	//Sexe
	/*radiobutton1 = lookup_widget(button,"radio_homme_modif_yahyaa");
	radiobutton2 = lookup_widget(button,"radio_femme_modif_yahya");
	if (genre1==1)
		{strcpy(nouv.Sexe,"homme");}
	else 
		{strcpy(nouv.Sexe,"femme");}*/

	x=modifier_adamy( "utilisateur.txt", cin , nouv);	

}


void
on_btn_confirmer_supp_yahya_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
int x ;
  int cin;
  char CIN[10];
  utilisateur u;
  GtkWidget *CINSUPP;
  CINSUPP=lookup_widget(button,"entry_cin_supp_yahya");	
  strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(CINSUPP)));
  cin=atoi(CIN);
  x=supprimer_adamy("utilisateur.txt",cin);
  GtkWidget *fenetre_gestion;//f2
  GtkWidget *fenetre_CINS;//f2
  fenetre_gestion = lookup_widget(button,"windowgestionadam");
  fenetre_gestion = create_windowgestionadam();
  gtk_widget_show (fenetre_gestion);
  fenetre_CINS = create_windowsupprimeradam();
  gtk_widget_hide (fenetre_CINS);
}


void
on_button_general_admin_yahya_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *General, *windowgestionadam;
 windowgestionadam= create_windowgestionadam ();
gtk_widget_show (windowgestionadam);
General = lookup_widget(button,"General");
gtk_widget_hide (General);

  
}


void
on_buttonexit_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *windowstatistique , *fenetre_gestion;
  windowstatistique = lookup_widget(button,"windowstatistique");
  gtk_widget_hide(windowstatistique);
  fenetre_gestion = lookup_widget(button,"windowgestionadam");
  fenetre_gestion = create_windowgestionadam();
  gtk_widget_show(fenetre_gestion);
}


void
on_buttonconfirmerra_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur u;
GtkWidget *sortie;
  sortie = lookup_widget(button,"labelsortieeyahya");
  float x =0;
  char v[20];
  //x=agemoyen(u);
  //v= atoi(x);
 // gtk_label_set_text(GTK_LABEL(sortie),v);
 
}

