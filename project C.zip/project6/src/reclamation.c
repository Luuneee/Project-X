#include "reclamation.h"
#include <gtk/gtk.h>
enum 
{
	IDD,
     TYPEREC_R,
     ID_LISTE,
     NBV_V,
     TEXTEREC,
     N_COLUMNS,
    
};

int ajouterrec(char * reclamation, rec r )
{
    FILE * f=fopen("reclamation.txt", "a");
    if(f!=NULL)
    {
        fprintf(f,"%d %s %d %d %s \n",r.id,r.typerec,r.id_liste,r.nbv,r.textrec);
        fclose(f);
        return 1;
    }
    else return 0;
}
int modifierrec( char * reclamation, int id, rec nouv )
{
    int tr=0;
    rec r;
    FILE * f=fopen("reclamation.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %s %d %d %s\n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)
        {
            if(r.id==id)
            {
                fprintf(f2,"%d %s %d %d %s\n",nouv.id,nouv.typerec,nouv.id_liste,nouv.nbv,nouv.textrec);
                tr=1;
            }
            else
                fprintf(f2,"%d %s %d %d %s\n",r.id,r.typerec,r.id_liste,r.nbv,r.textrec);

        }
    }
    fclose(f);
    fclose(f2);
    remove("reclamation.txt");
    rename("nouv.txt", "reclamation.txt");
    return tr;

}
int supprimerrec(char * reclamation, int id)
{
    int tr=0;
    rec r;
    FILE * f=fopen("reclamation.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %s %d %d %s\n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)
        {
            if(r.id == id)
                tr=1;
            else 
		
                fprintf(f2,"%d %s %d %d %s\n",r.id,r.typerec,r.id_liste,r.nbv,r.textrec);
        }
    }
    fclose(f);
    fclose(f2);
    remove("reclamation.txt");
    rename("nouv.txt", "reclamation.txt");
    return tr;
}
rec chercherrec(char * reclamation, int id)
{rec r;
    int tr=0;
    FILE * f=fopen("reclamation.txt", "r");
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%d %s %d %d %s\n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)
        {
            if(r.id==id || r.id_liste==id ||r.nbv==id)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        r.id=-1;
    return r;
}


void afficher_reclamation(GtkWidget *pListView) 
{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
	int id;
    	char typerec [30];
    	int id_liste;
    	int nbv;
    	char textrec [200];
	rec r;
char var1[20],var2[30],var3[20],var4[20],var5[200];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id",pCellRenderer,"text", IDD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("typerec",pCellRenderer,"text",TYPEREC_R,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id_liste",pCellRenderer,"text", ID_LISTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nbv",pCellRenderer,"text", NBV_V,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("textrec",pCellRenderer,"text", TEXTEREC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);





pListStore = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("reclamation.txt","r");
if (f==NULL){return;}

else{
f=fopen("reclamation.txt","a+");

while(fscanf(f,"%d %s %d %d %s \n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)

{

sprintf(var1,"%d",r.id);
sprintf(var2,"%s",r.typerec);
sprintf(var3,"%d",r.id_liste);
sprintf(var4,"%d",r.nbv);
sprintf(var5,"%s",r.textrec);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,IDD,var1,TYPEREC_R,var2,ID_LISTE,var3,NBV_V,var4,TEXTEREC,var5,-1);

}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}


}

void afficher_recherche(GtkWidget *pListView) 
{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
	int id;
    	char typerec [30];
    	int id_liste;
    	int nbv;
    	char textrec [200];
	rec r;
char var1[20],var2[30],var3[20],var4[20],var5[200];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id",pCellRenderer,"text", IDD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("typerec",pCellRenderer,"text",TYPEREC_R,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id_liste",pCellRenderer,"text", ID_LISTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("nbv",pCellRenderer,"text", NBV_V,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("textrec",pCellRenderer,"text", TEXTEREC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);





pListStore = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("reclamation1.txt","r");
if (f==NULL){return;}

else{
f=fopen("reclamation1.txt","a+");

while(fscanf(f,"%d %s %d %d %s \n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)

{

sprintf(var1,"%d",r.id);
sprintf(var2,"%s",r.typerec);
sprintf(var3,"%d",r.id_liste);
sprintf(var4,"%d",r.nbv);
sprintf(var5,"%s",r.textrec);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,IDD,var1,TYPEREC_R,var2,ID_LISTE,var3,NBV_V,var4,TEXTEREC,var5,-1);

}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }
}

}

int nombre_reclamation()
{
int i=0;
rec r;
FILE *f;
f= fopen("reclamation.txt", "r");
while(fscanf(f, "%d %s %d %d %s \n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)
{
i++;

}
fclose(f);
return i;
}




int nombre_rec_parliste(int id)
{
int i=0;
rec r;
FILE * f;
f= fopen("reclamation.txt", "r");
while(fscanf(f, "%d %s %d %d %s \n",&r.id,r.typerec,&r.id_liste,&r.nbv,r.textrec)!=EOF)
{
if(id==r.id_liste)
{
i++;
}
}
fclose(f);
return i;
}


