#ifndef UTIL_H_INCLUDED
#define UTIL_H_INCLUDED
#include <stdio.h>
typedef struct utilisateur {
char Nom[20];
char Prenom[20];
char Sexe[20];
int  jour;
int  mois;
int  annee;
int  tel;
char Adresse[20];
int  CIN;
char Login[20];
char mdp[20];
char Role[20];
int  nbr_bv;
int  Vote;
}utilisateur;



void ajouter_adamy( utilisateur u );
void afficher_adamy(GtkWidget *liste,char chemin[100]);
int supprimer_adamy(char * filename, int cin);
utilisateur rechercher_adamy(char ROLE[30]);
int modifier_adamy(char *filename,int cin,utilisateur nouv);
void agemoyen(utilisateur u);
#endif // UTIL_H_INCLUDED


