#include <gtk/gtk.h>


#include <gtk/gtk.h>




void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_buttonajouterfedi_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonafficherfedi_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifierfedi_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Statistique_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsupprime_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonrechercherfedi_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonajoutreclamationfedi_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourfedi_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourmodiffedi_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Bouttonmodifierreclamationfedi_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontotrec_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsubmit_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonstateretour_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonespacereclamation_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonespaceelection_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radio_femme_adam_aj_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonretouryahyaaa_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonyahyahomme_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_adam_gestion__row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview_recher_yahya_gestion_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonyahyaajouteraa_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_supp_yahya_gestion_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_modif_gestion_yahya_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_retour_gestion_adam_acc_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_calcul_gestion_yahya_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_recher_yahya_gestion_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_affi_yahya_gestion_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_modif_ges_y_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_radio_homme_modif_yahyaa_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radio_femme_modif_yahya_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_btn_modif_c_yahya_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_confirmer_supp_yahya_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_general_admin_yahya_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonexit_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconfirmerra_clicked           (GtkButton       *button,
                                        gpointer         user_data);
