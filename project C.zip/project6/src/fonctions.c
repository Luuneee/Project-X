#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include<gtk/gtk.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<stdbool.h>
#include"fonctions.h"

enum 
{
 	NOM,
	PRENOM,
	SEXE,
	JOUR,
	MOIS, 
	ANNEE,
	TEL,
	ADRESSE,
	CIN,
	LOGIN,
	MDP,
	ROLE,
	NBR,
	VOTE,
	COLUMN};
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
void ajouter_adamy( utilisateur u)
{
    FILE * f=fopen("utilisateur.txt", "a");
    if(f!=NULL)
    {
        fprintf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,u.jour,u.mois,u.annee,u.tel,u.Adresse,u.CIN,u.Login,u.mdp,u.Role,u.nbr_bv,u.Vote);
        fclose(f);
        return 1;
    }
    else 
	return 0;
}
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////


void afficher_adamy(GtkWidget *liste,char chemin[100])
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char Nom[20];
	char Prenom[20];
	char Sexe[20];
	int  jour;
	int  mois;
	int  annee;
	int  tel;
	char Adresse[20];
	int  Cin;
	char Login[20];
	char mdp[20];
	char Role[20];
	int  nbr_bv;
	int  Vote;
	
	
	store=NULL;
	
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Prenom",renderer, "text",PRENOM,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour",renderer, "text",JOUR,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("mois",renderer, "text",MOIS,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("tel",renderer, "text",TEL,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADRESSE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("CIN",renderer, "text",CIN,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Login",renderer, "text",LOGIN,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("MDP",renderer, "text",MDP,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Role",renderer, "text",ROLE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nbr_bv",renderer, "text",NBR,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("Vote",renderer, "text",VOTE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		
		
	}
store=gtk_list_store_new(COLUMN, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT,G_TYPE_INT,G_TYPE_INT ,G_TYPE_STRING ,G_TYPE_INT,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_INT,G_TYPE_INT  );
	f=fopen(chemin,"r");
if(f==NULL)
{
return;
}
else
{
f= fopen(chemin,"a+");
while(fscanf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",Nom,Prenom,Sexe,&jour,&mois,&annee,&tel,Adresse,&Cin,Login,mdp,Role,&nbr_bv,&Vote)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set (store, &iter, NOM,Nom,PRENOM,Prenom,SEXE,Sexe,JOUR,jour,MOIS,mois,ANNEE,annee,TEL,tel,ADRESSE,Adresse,CIN,Cin,LOGIN,Login,MDP,mdp,ROLE,Role,NBR,nbr_bv,VOTE,Vote, -1);

}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
int supprimer_adamy(char * filename, int cin)
{
    int tr=0;
    utilisateur u;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.jour,&u.mois,&u.annee,&u.tel,u.Adresse,&u.CIN,u.Login,u.mdp,u.Role,&u.nbr_bv,&u.Vote)!=EOF)
        {
            if(u.CIN== cin)
                tr=1;
            else
                fprintf(f2,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,u.jour,u.mois,u.annee,u.tel,u.Adresse,u.CIN,u.Login,u.mdp,u.Role,u.nbr_bv,u.Vote);
        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////


utilisateur rechercher_adamy(char ROLE[30])
{

utilisateur u;
utilisateur A;
FILE *f,*g;
f=fopen("utilisateur.txt","r");
g=fopen("find.txt","w");

if(f==NULL || g==NULL)
	{return;}
else
{	
	while(fscanf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.jour,&u.mois,&u.annee,&u.tel,u.Adresse,&u.CIN,u.Login,u.mdp,u.Role,&u.nbr_bv,&u.Vote)!=EOF)
	{
		if (strcmp(u.Role,ROLE)==0)
		{
			fprintf(g,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,u.jour,u.mois,u.annee,u.tel,u.Adresse,u.CIN,u.Login,u.mdp,u.Role,u.nbr_bv,u.Vote);
			strcpy(A.Nom,u.Nom);
			strcpy(A.Prenom,u.Prenom);
			strcpy(A.Sexe,u.Sexe);
			A.jour=u.jour;
			A.mois=u.mois;
			A.annee=u.annee;
			A.tel=u.tel;
			A.CIN=u.CIN;
			strcpy(A.Adresse,u.Adresse);
			strcpy(A.Login,u.Login);
			strcpy(A.mdp,u.mdp);
			strcpy(A.Role,u.Role);
			A.nbr_bv=u.nbr_bv;
			A.Vote=u.Vote;	
		}
}
fclose(f);
fclose(g);
return A;
}
}
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
/*
void agemoyen(utilisateur u)
{
utilisateur u;
FILE *f= fopen("utilisateur.txt","r");
if (f !=NULL){
	utilisateur u;
	int age=0;
	int i=0;
	float moy=0;
	while(fscanf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",Nom,Prenom,Sexe,&jour,&mois,&annee,&tel,Adresse,&Cin,Login,mdp,Role,&nbr_bv,&Vote )!=EOF)
	{
			i++;
			age+= (2022-u.annee) ;
			moy=age/i;
				
}
	printf("age moy:\n %f \n",moy);
}

return 0;

}

*/



///////////////////////////////////////////////////////
///////////////////////////////////////////////////////

int modifier_adamy(char *filename,int cin,utilisateur nouv)
{
FILE*f=fopen(filename,"r");
FILE*f1=fopen("ancientutilisateur.txt","w+");
utilisateur u;
int y,tr=0;
if ( f!=NULL && f1!=NULL)
{
while(fscanf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.jour,&u.mois,&u.annee,&u.tel,u.Adresse,&u.CIN,u.Login,u.mdp,u.Role,&u.nbr_bv,&u.Vote)!=EOF)
{
	if(u.CIN==cin)
	{
		fprintf(f1,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",nouv.Nom,nouv.Prenom,nouv.Sexe,nouv.jour,nouv.mois,nouv.annee,nouv.tel,nouv.Adresse,nouv.CIN,nouv.Login,nouv.mdp,nouv.Role,nouv.nbr_bv,nouv.Vote);}
	else
		
		fprintf(f1,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,u.jour,u.mois,u.annee,u.tel,u.Adresse,u.CIN,u.Login,u.mdp,u.Role,u.nbr_bv,u.Vote);
}		
}
	fclose(f);
	fclose(f1);
	remove("utilisateur.txt");
	rename("ancientutilisateur.txt","utilisateur.txt");
	return tr;
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////


void agemoyen(utilisateur u)
{
float moy=0;
FILE *f= fopen("utilisateur.txt","r");
if (f !=NULL){
	utilisateur u;
	int age=0;
	int i=0;
	float moy=0;
	while(fscanf(f,"%s %s %s %d %d %d %d %s %d %s %s %s %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.jour,&u.mois,&u.annee,&u.tel,u.Adresse,&u.CIN,u.Login,u.mdp,u.Role,&u.nbr_bv,&u.Vote)!=EOF)
	{
			i++;
			age+= (2022-u.annee) ;
			moy=age/i;
							
}
return moy;	
}



}



