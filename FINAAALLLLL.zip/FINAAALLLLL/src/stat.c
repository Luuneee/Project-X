#include <stdio.h>
#include <stdlib.h>
#include "stat.h"
#include <string.h>
float TVB(char* filename)
{
 float taux;
 int nbr_vote=0;
 int nbr_voteB=0;
 utilisateur u;
 FILE * f=fopen("utilisateursLA.txt", "r+");
 if(f!=NULL)
  { while (fscanf(f,"%s %s %s %d %s %d %s %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.Age,u.Adresse,&u.tel,u.Role,&u.id_bv,&u.Vote)!=EOF)
       {
           if ((u.Vote!=-1)&&(strcmp(u.Role,"electeur")==0))
                nbr_vote++;
           if ((u.Vote==0)&&(strcmp(u.Role,"electeur")==0))
                nbr_voteB++; } }

taux=(float) nbr_voteB*100/nbr_vote;
fclose(f);
return taux; }


int nbr_e(char* filename,int id)
{ int nbe=0;
  utilisateur u;
  FILE * f=fopen("utilisateursLA.txt", "r");
	printf("%s",u.Role);
   if(f!=NULL)
  { while (fscanf(f,"%s %s %s %d %s %d %s %d %d \n",u.Nom,u.Prenom,u.Sexe,&u.Age,u.Adresse,&u.tel,u.Role,&u.id_bv,&u.Vote)!=EOF)
     { 
         if((id==u.id_bv)&&(strcmp(u.Role,"electeur")==0))
            nbe++; }
   fclose(f); }
   return nbe;
 }


