#ifndef TEST_H_INCLUDED
#define TEST_H_INCLUDED
#include <stdio.h>
typedef struct  
{int  CIN ;
char Nom [20] ;
char Prenom [20] ;
char Sexe [10] ;
int  Age ;
char Adresse[20] ;
int  tel;
char Role[30];
int  id_bv;
int  Vote;
}utilisateur;
float TVB(char* filename);
int nbr_e(char* filename,int id);
#endif // TEST_H_INCLUDED

