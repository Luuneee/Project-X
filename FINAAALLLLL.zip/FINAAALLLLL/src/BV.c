#include "BV.h"
#include <stdio.h>
#include <string.h> 

#include <stdlib.h>
#include <gtk/gtk.h>
enum 
{
	IDD,
     CAPACITE_E,
     CAPACITE_OBS,
    ADDRESSE,
     SALLE,
     ID_A,
     N_COLUMNS,
};

 
 int ajouter(char * filename, BureauVote bv )
{
	FILE * f=fopen(filename, "a"); 
    if(f!=NULL)
    {
        fprintf(f,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
        fclose(f);
        return 1;
    }
    else
     return 0;
}

int modifier(char * filename, int ID, BureauVote new)
{
   int tr=0;
   BureauVote bv;
   FILE * f;
   FILE * f1;
   f=fopen(filename, "r");
   f1=fopen("new.txt","w");
   if((f!=NULL)&&(f1!=NULL))
   {
       while (fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec,&bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF)
       {
           if(bv.ID_Bv==ID)
           {
               fprintf(f1,"%d %d %d %s %d %d\n",new.ID_Bv, new.capacite_elec, new.capacite_obs, new.addresse, new.salle, new.id_agent );
               tr=1;
           }
           else
            fprintf(f1,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
       }

   }
   fclose(f);
   fclose(f1);
   remove(filename);
   rename("new.txt",filename);
   return tr;
}
int supprimer(char * filename, int ID)
{
    int tr=0;
    BureauVote bv;
    FILE * f=fopen(filename, "r");
    FILE * f1=fopen("nouv.txt", "w");
    if(f!=NULL && f1!=NULL)
    {
        while (fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF)
        {
            if(bv.ID_Bv==ID)
            {
               tr=1;
            }

            else
                fprintf(f1,"%d %d %d %s %d %d\n",bv.ID_Bv, bv.capacite_elec, bv.capacite_obs, bv.addresse, bv.salle, bv.id_agent);
        }
    }
    fclose(f);
    fclose(f1);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
} 
BureauVote chercher(char * filename, int ID)
{
    BureauVote bv;
    int tr=0;
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF)
        {
            if(bv.ID_Bv== ID)
            {
                tr=1;
            }

        }
    }
    fclose(f);
    if(tr==0)
        bv.ID_Bv=-1;
    return bv;

}
void afficher_BureauVote(GtkWidget *pListView) 
{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
	int ID_Bv;
    	int capacite_elec;
    	int capacite_obs;
    	char addresse[20];
    	int salle;
    	int id_agent;
	BureauVote bv;
char var1[20],var2[20],var3[20],var4[20],var5[20];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("ID_Bv",pCellRenderer,"text", IDD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("capacite_elec",pCellRenderer,"text",CAPACITE_E,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("capacite_obs",pCellRenderer,"text", CAPACITE_OBS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("addresse",pCellRenderer,"text", ADDRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("salle",pCellRenderer,"text", SALLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id_agent",pCellRenderer,"text", ID_A,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);




pListStore = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("bv.txt","r");
if (f==NULL){return;}

else{
f=fopen("bv.txt","a+");

while(fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF)

{

sprintf(var1,"%d",bv.ID_Bv);
sprintf(var2,"%d",bv.capacite_elec);
sprintf(var3,"%d",bv.capacite_obs);
sprintf(var4,"%d",bv.salle);
sprintf(var5,"%d",bv.id_agent);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,IDD,var1,CAPACITE_E,var2,CAPACITE_OBS,var3,ADDRESSE,bv.addresse,SALLE,var4,ID_A,var5,-1);

}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}

}


void affiche_BureauVote(GtkWidget *pListView) 
{
GtkListStore *pListStore;
GtkTreeViewColumn *pColumn;
GtkCellRenderer *pCellRenderer;
GtkTreeIter pIter;
	int ID_Bv;
    	int capacite_elec;
    	int capacite_obs;
    	char addresse[20];
    	int salle;
    	int id_agent;
	BureauVote bv;
char var1[20],var2[20],var3[20],var4[20],var5[20];

pListStore=NULL;
FILE *f;
pListStore=gtk_tree_view_get_model(pListView);

if (pListStore== NULL) {

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("ID_Bv",pCellRenderer,"text", IDD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("capacite_elec",pCellRenderer,"text",CAPACITE_E,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("capacite_obs",pCellRenderer,"text", CAPACITE_OBS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("addresse",pCellRenderer,"text", ADDRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("salle",pCellRenderer,"text", SALLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);

pCellRenderer = gtk_cell_renderer_text_new();
pColumn = gtk_tree_view_column_new_with_attributes("id_agent",pCellRenderer,"text", ID_A,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(pListView), pColumn);




pListStore = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("recherche.txt","r");
if (f==NULL){return;}

else{
f=fopen("recherche.txt","a+");

while(fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF)

{

sprintf(var1,"%d",bv.ID_Bv);
sprintf(var2,"%d",bv.capacite_elec);
sprintf(var3,"%d",bv.capacite_obs);
sprintf(var4,"%d",bv.salle);
sprintf(var5,"%d",bv.id_agent);

gtk_list_store_append(pListStore, &pIter);

gtk_list_store_set(pListStore, &pIter,IDD,var1,CAPACITE_E,var2,CAPACITE_OBS,var3,ADDRESSE,bv.addresse,SALLE,var4,ID_A,var5,-1);

}


fclose(f);


gtk_tree_view_set_model(GTK_TREE_VIEW(pListView),GTK_TREE_MODEL(pListStore));

g_object_unref(pListStore);

       }

}

}
int verif(char *filename,BureauVote b)
{
BureauVote bv;
    int tr=0;
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%d %d %d %s %d %d\n",&bv.ID_Bv, &bv.capacite_elec, &bv.capacite_obs,bv.addresse, &bv.salle, &bv.id_agent)!=EOF)
        {
            if((strcmp(bv.addresse,b.addresse)==0)&&(bv.salle==b.salle))
            {
                return 0;
            }
    }}
    fclose(f);       
    return 1;
}

