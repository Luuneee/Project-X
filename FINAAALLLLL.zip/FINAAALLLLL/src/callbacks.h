#include <gtk/gtk.h>


void
on_retour_bv_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_bv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_button_confirmer_ajout_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_bv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_aller_supprimer_bv_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aller_afficher_bv_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_aller_modifier_bv_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_aller_ajouter_bv_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_numerobv_modif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifbv_adresse_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_idagent_modifbv_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifbv_numerosalle_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retour_gestion_bv_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_bv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refrech_bv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_affich_bv_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_non_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_taux_vb_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_stat_bv_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
